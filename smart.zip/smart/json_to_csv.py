import json
import csv

# Load the JSON data
with open('factory_data.json') as json_file:
    data = json.load(json_file)

# Make sure data is a list of entries
if not isinstance(data, list):
    data = [data]

# Open CSV file to write
with open('factory_data.csv', mode='w', newline='') as csv_file:
    fieldnames = data[0].keys()
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

    writer.writeheader()
    for entry in data:
        writer.writerow(entry)

print("✅ JSON converted to CSV: factory_data.csv")
